package com.example.akaash.assignment8_2;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by AKAASH on 07-11-2017.
 */

public class CustomList extends ArrayAdapter<String>
{

    private final Activity context;
    private final String[] name;
    private final String[] phone;

    public CustomList(Activity context, String[] name, String[] phone) {
        super(context, R.layout.custom_list,name);
        this.context=context;
        this.name=name;
        this.phone=phone;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent)
    {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_list, null,true);

        TextView txtName = (TextView) rowView.findViewById(R.id.txtname);
        TextView txtPhone = (TextView) rowView.findViewById(R.id.txtphone);


        txtName.setText(name[position]);
        txtPhone.setText(phone[position]);

        return rowView;
    }
}
