package com.example.akaash.assignment8_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list=(ListView)findViewById(R.id.contact_list);
        final String[] name={"Ram","John","Kelvin","Krishna","Sita","Gita"};
        String[] phone={"9987656745","8876543423","7789564534","4435768978","7765893423","9977553325"};

        CustomList customList=new CustomList(MainActivity.this,name,phone);
        list.setAdapter(customList);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedItem=name[i];
                Toast.makeText(getApplicationContext(),selectedItem,Toast.LENGTH_LONG).show();
            }
        });
    }
}
